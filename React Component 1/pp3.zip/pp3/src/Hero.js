// Write this code in Hero.js file
import { Component } from "react"; 

export default class Hero extends Component {
    render() {
      return (
        <div className="hero">
          <h3>NFTium is the best place to find cool and unique NFTs </h3>
          <img
            src="https://res.cloudinary.com/dl26pbek4/image/upload/v1672553422/cn-questions/Capture_yihdy3.png"
            alt="nft"
          />
        </div>
      );
    }
  }